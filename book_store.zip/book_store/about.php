    <section class="page-section">
        <div class="container">
            <h2 class="text-center">About Us</h2>
    <?php echo html_entity_decode($_SESSION['system']['about_content']) ?>        
            
        </div>
        </section>